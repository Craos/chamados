create view dashboard_chamados_resumo(situacao, cor, img, percent, p) as
SELECT a.nome                                                                                                         AS situacao,
       a.cor,
       a.img,
       (sum(a.registros::double precision / a.total::double precision) * 100::double precision)::integer ||
       '%'::text                                                                                                      AS percent,
       (sum(a.registros::double precision / a.total::double precision) *
        100::double precision)::integer                                                                               AS p
FROM (SELECT (SELECT count(*) AS count
              FROM chamados chamados_1) AS total,
             s.nome,
             s.cor,
             s.img,
             count(*)                   AS registros
      FROM chamados
               JOIN situacao s ON chamados.situacao = s.id
      GROUP BY s.nome, s.cor, s.img) a
GROUP BY a.nome, a.cor, a.img;

alter table dashboard_chamados_resumo
    owner to postgres;

