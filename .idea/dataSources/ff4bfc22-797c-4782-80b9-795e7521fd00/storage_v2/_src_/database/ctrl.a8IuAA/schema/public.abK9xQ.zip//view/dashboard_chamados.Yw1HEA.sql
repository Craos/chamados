create view dashboard_chamados(cliente, situacao, chamados) as
SELECT c.nome   AS cliente,
       s.nome   AS situacao,
       count(*) AS chamados
FROM chamados
         JOIN clientes c ON chamados.cliente = c.id
         JOIN situacao s ON chamados.situacao = s.id
GROUP BY c.nome, s.nome;

alter table dashboard_chamados
    owner to postgres;

