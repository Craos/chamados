create view dashboard_chamados_max(situacao, cor, img, percent, p) as
SELECT dashboard_chamados_resumo.situacao,
       dashboard_chamados_resumo.cor,
       dashboard_chamados_resumo.img,
       dashboard_chamados_resumo.percent,
       dashboard_chamados_resumo.p
FROM dashboard_chamados_resumo
WHERE (dashboard_chamados_resumo.p IN (SELECT max(dashboard_chamados_resumo_1.p) AS max
                                       FROM dashboard_chamados_resumo dashboard_chamados_resumo_1
                                       LIMIT 1));

alter table dashboard_chamados_max
    owner to postgres;

